# Food Ordering and Preparation Queue System

A console-based Java application for a small restaurant or cafeteria. It records customer orders, places them in a preparation line, and lets staff prepare them in the order they arrived. Sorting algorithms written from scratch help staff review the order records.

**Author:** _Your Name_
**Course / Section:** _Your Course and Section_
**Instructor:** _Instructor Name_

---

## Project Description

In a busy cafeteria, orders pile up quickly. If staff prepare orders in a random sequence, customers who came first end up waiting longest, which is unfair and causes complaints. Staff also need a quick way to look through the day's orders, for example to find the biggest orders or to look up a customer alphabetically.

This system handles both problems:

1. **Queue (FIFO):** Orders placed in the preparation queue are prepared strictly in the order they were added. The first order in is the first order out.
2. **Sorting:** The recorded orders can be sorted by total amount (Bubble Sort) or by customer name (Selection Sort) so staff can review them easily.

The program uses procedural programming only. There are no custom classes or objects. All logic lives in `static` methods and all data is kept in `ArrayList`s.

## Objectives

- Store and manage food order records using several synchronized `ArrayList`s.
- Implement Bubble Sort and Selection Sort manually, without any built-in sorting method.
- Manage the preparation line with a `Queue` (`LinkedList`) that follows FIFO.
- Make sure sorting the records never changes the order in which orders are prepared.
- Provide a menu-driven console interface that validates input and never crashes on bad data.
- Support adding, displaying, searching, updating, and deleting orders.

## Use Cases and Features

| Menu | Feature | What it does |
|------|---------|--------------|
| 1 | Add new order | Records customer name, food item, quantity, and price. Total is computed automatically. Offers to queue the order right away. |
| 2 | Display all orders | Shows every record in a table. |
| 3 | Search | Find an order by order number or by customer name (partial, not case-sensitive). |
| 4 | Update | Change the customer name, food item, quantity, or price of an order that is not yet completed. |
| 5 | Delete | Removes an order from every list. If the order was in the queue, it is removed from the queue too. |
| 6 | Enqueue | Adds one waiting order to the back of the preparation queue. |
| 7 | Enqueue all waiting | Adds every waiting order to the queue, lowest order number first. |
| 8 | Dequeue | Prepares the order at the front of the queue and marks it Completed. |
| 9 | Peek | Shows the next order without removing it. |
| 10 | Display queue | Shows the queue from front to back with positions. |
| 11 | Check if empty | Reports whether the queue is empty. |
| 12 | Bubble Sort | Sorts records by total amount (ascending or descending). |
| 13 | Selection Sort | Sorts records by customer name (A to Z or Z to A). |
| 14 | Pending / Completed | Lists pending orders and completed orders separately. |
| 15 | Load sample orders | Adds five sample orders, useful for testing and screenshots. |
| 0 | Exit | Closes the program. |

Order status moves through three stages: `Waiting` (recorded), `In Queue` (waiting to be prepared), and `Completed` (prepared).

## Data Structure Explanation

### ArrayLists (records)

Each order is spread across six parallel `ArrayList`s. The value at index `i` in every list belongs to the same order.

| ArrayList | Type | Holds |
|-----------|------|-------|
| `orderIds` | `Integer` | Order number (starts at 1001) |
| `customerNames` | `String` | Customer name |
| `itemNames` | `String` | Food item ordered |
| `quantities` | `Integer` | Number of items |
| `totalAmounts` | `Double` | Quantity multiplied by price |
| `statuses` | `String` | Waiting, In Queue, or Completed |

Whenever a record is added, deleted, or swapped during sorting, all six lists are changed together so the indexes stay aligned. The method `swapRecords(a, b)` swaps all six lists at once, and `deleteOrder()` removes the same index from all six.

### Queue (preparation line)

```java
static Queue<Integer> prepQueue = new LinkedList<>();
```

The queue stores **order numbers only**, not full records. This is the key design decision:

- The record lists can be sorted freely, and the queue is not affected because it only holds order numbers.
- When an order is dequeued, the program looks up its record with `findIndexById(id)`.

| Queue operation | Method used |
|-----------------|-------------|
| Enqueue | `prepQueue.add(id)` |
| Dequeue | `prepQueue.poll()` |
| Peek | `prepQueue.peek()` |
| Display | iterate with a for-each loop (front to back) |
| Empty check | `prepQueue.isEmpty()` |

## Sorting Algorithm Explanation

Both algorithms are written by hand. No `Arrays.sort()`, `Collections.sort()`, or other built-in sorting is used. Both use `swapRecords()` so every ArrayList stays in sync.

### 1. Bubble Sort: by total amount (`bubbleSortByTotal`)

**How it works:** The algorithm walks through the list and compares each pair of neighbors. If a pair is out of order, they are swapped. After each pass, the largest remaining value has "bubbled" to its final position at the end. If a full pass makes no swaps, the list is already sorted and the algorithm stops early.

**Why it fits this use case:** Order totals are numbers, and a restaurant's daily list is small. Bubble Sort is simple to follow and the early-exit check makes it fast when the list is already nearly sorted. Staff use it to see the biggest or smallest orders first.

### 2. Selection Sort: by customer name (`selectionSortByName`)

**How it works:** For each position from the front, the algorithm scans the unsorted part to find the smallest (or largest) name, then swaps it into place. Names are compared with `compareToIgnoreCase`, so uppercase and lowercase do not affect the result.

**Why it fits this use case:** Selection Sort makes at most one swap per position, which means fewer record swaps. Since each swap moves six lists, that is a real saving. It is a good match for alphabetical lookup of customers.

### Sorting and the queue

Sorting changes only the **record lists**. The queue holds order numbers in arrival order, so the FIFO sequence is unaffected. The program prints the queue before and after each sort to show this.

## How to Run the Program

**Requirements:** Java Development Kit (JDK) 8 or newer.

Check your installation:

```bash
java -version
javac -version
```

Compile and run from the project folder:

```bash
javac -d out src/Main.java
java -cp out Main
```

On Windows Command Prompt the same commands work. If `javac` is not recognized, install a JDK and make sure it is added to your PATH.

## Screenshots of the System

> Replace each file in the `screenshots/` folder with your own capture from the running program. Every image must be a real screenshot of this application.

### 1. Main menu
![Main menu](screenshots/main-menu.png)
*The main menu showing all available options.*

### 2. Adding records and displaying stored records
![Add and display records](screenshots/add-display-records.png)
*Adding an order and viewing the stored records in the table.*

### 3. Queue operations
![Queue operations](screenshots/queue-operations.png)
*Enqueue, peek, dequeue, and displaying the queue.*

### 4. FIFO behavior
![FIFO behavior](screenshots/fifo-behavior.png)
*Orders are prepared in the same order they were added to the queue.*

### 5. Bubble Sort (before and after)
![Bubble Sort](screenshots/sorting-bubble.png)
*Records sorted by total amount using Bubble Sort. The queue order stays the same.*

### 6. Selection Sort (before and after)
![Selection Sort](screenshots/sorting-selection.png)
*Records sorted by customer name using Selection Sort. The queue order stays the same.*

### 7. Input validation and error messages
![Input validation](screenshots/input-validation.png)
*Invalid menu choices, empty fields, bad numbers, and empty-queue messages.*

## Test Cases

| # | Scenario | Steps | Expected result |
|---|----------|-------|-----------------|
| 1 | Add valid order | Option 1, name `Maria Cruz`, item `Fried Chicken`, qty `2`, price `100` | Order #1001 saved, total 200.00, status Waiting |
| 2 | Invalid name | Option 1, enter `Mar1a` | Error message, prompt repeats |
| 3 | Invalid quantity | Enter `0`, `51`, `abc` as quantity | Error each time, prompt repeats |
| 4 | Invalid price | Enter `-5`, `0`, `abc` as price | Error each time, prompt repeats |
| 5 | Invalid menu choice | Enter `99`, `-1`, `abc`, blank | Error message, menu shown again |
| 6 | Empty list | Choose 2, 3, 4, 5, 12, 13 with no orders | "No orders" style message, no crash |
| 7 | Empty queue | Choose 8, 9, 10 with nothing queued | "Queue is empty" message |
| 8 | Check empty | Option 11 on empty queue, then after queuing | "EMPTY", then "NOT empty" with count |
| 9 | Enqueue | Load samples (15), enqueue 1001 then 1002 | Queue shows #1001 -> #1002 |
| 10 | Duplicate enqueue | Enqueue 1001 twice | Second attempt says already in queue |
| 11 | Missing order | Enqueue, search, update, or delete order `9999` | "No order found" message |
| 12 | FIFO | Option 7, then option 8 five times | Orders complete as 1001, 1002, 1003, 1004, 1005 |
| 13 | Peek | Option 9 | Shows front order and it stays in the queue |
| 14 | Bubble Sort ascending | Load samples, option 12, ascending | Totals 95.50, 140.00, 180.00, 240.00, 255.00 |
| 15 | Bubble Sort descending | Option 12, descending | Totals 255.00, 240.00, 180.00, 140.00, 95.50 |
| 16 | Selection Sort A to Z | Option 13, ascending | Ana, Carlo, Juan, Liza, Maria |
| 17 | Selection Sort Z to A | Option 13, descending | Maria, Liza, Juan, Carlo, Ana |
| 18 | Sort keeps queue intact | Queue 1001-1005, sort by either method | "Queue order" line identical before and after |
| 19 | Records stay synchronized | Sort, then search order 1003 | Customer, item, qty, total all match the original order |
| 20 | Update | Update qty of an order | Total recalculates from the same price |
| 21 | Update completed order | Update an order already completed | Refused with a message |
| 22 | Delete queued order | Delete an order that is In Queue | Removed from records and from the queue |
| 23 | Search by name | Search `mar` | Lists all customers containing "mar" |
| 24 | Pending/Completed | Complete two orders, option 14 | Two lists shown separately with counts |

## Project Structure

```
DSA-Java-Sorting-Queue-Capstone/
├── src/
│   └── Main.java
├── screenshots/
│   ├── main-menu.png
│   ├── add-display-records.png
│   ├── queue-operations.png
│   ├── fifo-behavior.png
│   ├── sorting-bubble.png
│   ├── sorting-selection.png
│   └── input-validation.png
├── .gitignore
└── README.md
```

## Notes on Procedural Design

- The only class is `Main`, which Java requires as the program entry point. No other classes, objects, inheritance, or interfaces are used.
- Data is stored in static `ArrayList`s and one static `Queue`.
- Every feature has its own `static` method.
